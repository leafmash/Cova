package com.kotha.app

import android.app.Application
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.ProcessLifecycleOwner
import com.kotha.app.data.app.AppForeground
import com.kotha.app.data.call.CallCoordinator
import com.kotha.app.notify.NotificationChannels
import dagger.hilt.android.HiltAndroidApp
import javax.inject.Inject

@HiltAndroidApp
class CovaApplication : Application() {

    @Inject
    lateinit var appForeground: AppForeground

    @Inject
    lateinit var callCoordinator: CallCoordinator

    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensure(this)
        callCoordinator.start()
        ProcessLifecycleOwner.get().lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onStart(owner: LifecycleOwner) {
                appForeground.set(true)
            }

            override fun onStop(owner: LifecycleOwner) {
                appForeground.set(false)
            }
        })
    }
}
